from django.http import HttpResponse
from django.shortcuts import render,redirect
from User_App.views import *
from hashlib import sha1
from . import Ver
# Create your views here.


def register(request):
    if request.method == 'GET':
        return render(request, 'register.html')
    else:
        if request.POST['upwd']!=request.POST['upwd2']:
            errMsg = '两次密码不一致'
            return render(request,'register.html',{'errMsg':errMsg})
        elif request.POST['uname']=='':
            errMsg1 = "用户名不能为空"
            return render(request,'register.html',{'errMsg1':errMsg1})
        else:
            insert(request)
            #把用户名存入cookies
            uname = request.POST['uname']
            #密码加密存入cookies
            upwd = request.POST['upwd']
            s1 = sha1()
            s1.update(upwd.encode('utf-8'))
            upwd = s1.hexdigest()
            resp = redirect('/index')
            resp.set_cookie('uname',uname,60*60*24*365)
            resp.set_cookie('upwd',upwd,60*60*24*365)
            request.session['is_login']=True
            return resp

def register_name(request):
    name = request.GET.get('name')
    print("name:", name)
    uname = select_uname(request,name)
    print("uname:",uname)

    if uname == name:
        return HttpResponse('用户名已存在')
    if uname!=name:
        return HttpResponse('可以使用的用户名')


