from django.apps import AppConfig


class TagAppConfig(AppConfig):
    name = 'Tag_App'
