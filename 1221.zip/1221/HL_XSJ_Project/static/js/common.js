function createxhr() {
            if(window.XMLHttpRequest){
                var xhr = new XMLHttpRequest();
            }
            else{
                var xhr = new AcitvieXObject("Microsoft.XMLHTTP");
            }
            return xhr;
            }