/**
 * Created by tarena on 18-12-15.
 */
function Ver() {
        var char = 'A B C D E F G H I J K L M N O P Q R S T U V W X Y Z a b c d e f g h i j k l m n o p q r s t u v w x y z 0 1 2 3 4 5 6 7 8 9'
        char = char.split(' ')
        var span = char[Math.ceil(Math.random()*61)]
        return span
    }
$(function () {
    var span1 = Ver()
    var span2 = Ver()
    var span3 = Ver()
    var span4 = Ver()
    $("#span1").html(span1)
    $("#span2").html(span2)
    $("#span3").html(span3)
    $("#span4").html(span4)
    $(".yz #yz").blur(function () {
        var yz_text = $("#yz").val()
        if (yz_text.toUpperCase() == (span1 + span2 + span3 + span4).toUpperCase()) {
            $(".yz #span5").text("验证码正确")
        } else {
            $(".yz #span5").text("验证码错误")
        }
    })
    $(".form_btn #sub").click(function () {
        if($(".yz #span5").text()=='验证码错误' | $(".sss").text()=='用户名已存在'){
            return false
        }
    })
    $(".form_text_ipt .uname").blur(function () {
            $.ajax({
            url:'/register/uname',
            type:'GET',
            data:{"name":$(".form_text_ipt .uname").val()},
            dataType:'text',
            async: true,
            success:function (data) {
                $(".sss").html(data)
                }

        })
    })

})

