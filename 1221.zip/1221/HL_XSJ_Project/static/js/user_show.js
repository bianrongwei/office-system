/**
 * Created by tarena on 18-12-17.
 */
//设置查询条件多选框
var nextState=1;
function onblue1(obj,id) {
    var liArray =  $('#'+id+" li");
    var i = 1;
    var length = liArray.length;
    for(;i<length;i++){
       obj.innerHTML = "当前选择↓";
        liArray[i].className = "liHide";
    }
}

//查询客户信息
function query() {
    console.log('开始查询')
        $.ajax({
            type: 'GET',
            url : "/user/select",
            dataType:'json',
            success : function(ret) {
                console.log('查询结果'+ret)
                var html = ''
                $('#tableShow')[0].className = 'liShow'
                $.each(ret,function (i,User) {

                    html += "<tr>"
                    html += "<td id='uid' class='liHide'>"+User.id+"</td>"
                    html += '<td><input type="checkbox" class="checkbox" name="check"></td>'
                    html += "<td>"+(1+i)+"</td>"
                    html += "<td id='cname' >"+User.name+"</td>"
                    html += "<td>"+User.sex+"</td>"
                    html += "<td>"+User.birth_data+"</td>"
                    html += "<td>"+User.mobie+"</td>"
                    html += "<td>"+User.email+"</td>"
                    html += "<td>"+User.address+"</td>"
                    html += "<td>"+User.professional+"</td>"
                    html += "<td>"+User.login_address+"</td>"
                    html += "<td ><a href="+"'/user/updUser?uid="+User.id+"'>修改</a><button id='delUser'>删除</button></td>"
                    html += "</tr>"


                })
                $('#showUser').html(html)
            }
        })
    }



//点击查询后
$(function () {
    console.log('开始渲染')
    //点击查询按钮事件
    $('#btnQuery').click(query)

	//1.全选和取消全选
	var isTrue = false;
	//更改状态标识
	$('#checkall').click(function (){

		isTrue = !isTrue;
		if (isTrue){
			$("[name=check]").prop("checked","true")
		}else{
			$("[name=check]").removeAttr("checked");
			}
	});
	/*2.反选
	onchange事件
	输入框监听,来判断两次输入是否一致
	按钮监听,选中与取消状态改变
	*/
    $(document).on("change","[name='check']",function() {

            console.log('1232342')
            //判断商品复选框,未被选中的按钮数量<=0,说明全选
            //:eq  :not()
            //eq(index)根据下标获取元素
            //not('')获取元素,给出否定条件
            //input:check 匹配别选中的输入框
            //size()获取数组长度,元素个数
            var isAll = $("[name=check]").not("input:checked").size() <= 0;
            if (isAll) {
                //修改全选按钮
                $('#checkall').prop("checked", "true");
                isTrue = true;
            } else {
                $("#checkall").removeAttr("checked");
                isTrue = false;
            }

        });

	//3.客户删除
	$(document).on("click","#delUser",function (){
	    console.log('开始删除')
		uid = $(this).parent().siblings('#uid').html()
		var dic = {
			"uid":uid,
		}
		console.log(uid)
		$.ajax({
            type: 'POST',
            data: dic,
            traditional: true,
            url: "/user/delUser",
            success: function () {
                console.log('ddd')
                alert('删除成功')
					query()
            }
        })

	});


});
