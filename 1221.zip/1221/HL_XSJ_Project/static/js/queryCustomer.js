/**
 * Created by tarena on 18-12-17.
 */
//设置查询条件多选框
var nextState=1;
function onblue1(obj,id) {
    var liArray =  $('#'+id+" li");
    var i = 1;
    var length = liArray.length;
    for(;i<length;i++){
       obj.innerHTML = "当前选择↓";
        liArray[i].className = "liHide";

    }
}
//设置查询条件多选框
function change(obj,id) {
    var liArray = $('#'+id+" li");
    var i = 1;
    var length = liArray.length;
    switch (nextState) {
        case 1:
            obj.innerHTML = "当前选择↑";
            for (; i < length; i++) {
                liArray[i].className = "liShow";
            }
            nextState = 0;
            break;
        case 0:
            obj.innerHTML = "当前选择↓";
            for (; i < length; i++) {
                liArray[i].className = "liHide";
            }
            nextState = 1;
    }
}
//获取复选类选择的值
function getValueByName(name) {
        obj = document.getElementsByName(name)
        Values = []
        for (key in obj){
            if(obj[key].checked) {
                Values.push(obj[key].value)
            }
        }
        return Values
}
//获取input输入的值
function getValueById(id) {
        obj = document.getElementById(id)
        return obj.value
}
//获取选择客户所选择客户id
function getIdByCheck() {
    var arr = $('#showCustomer input:checked').parents('tr').find('#cid').map(function () {
        return $(this).html()
    })
    var l = []
    for(var i=0;i<arr.length;i++) {
        l[l.length] = arr[i]
    }
    return l
}


//查询客户信息
function query() {
        sexValues = getValueByName('sex')
        startCtime = getValueById('startCtime')
        stopCtime = getValueById('stopCtime')
        startBirthday = getValueById('startBirthday')
        stopBirthday = getValueById('stopBirthday')
        cname = $('[name=queryName]').val()
        $.ajax({
            type: 'POST',
            data: {
                sex:sexValues,
                'startCtime':startCtime,
                'stopCtime':stopCtime,
                'startBirthday':startBirthday,
                'stopBirthday':stopBirthday,
                'cname':cname
            },
            traditional: true,
            url : "/customer/query-customers",
            dataType:'json',
            success : function(ret) {
                var html = ''
                    $('#tableShow')[0].className = 'liShow'
                $.each(ret,function (i,cus) {
                    html += "<tr>"
                    html += "<td id='cid' class='liHide'>"+cus.cid+"</td>"
                    html += '<td><input type="checkbox" class="checkbox" name="check"></td>'
                    html += "<td>"+(1+i)+"</td>"
                    html += "<td id='cname' >"+cus.name+"</td>"
                    html += "<td>"+cus.sex+"</td>"
                    html += "<td>"+cus.birthday+"</td>"
                    html += "<td id='mobie'>"+cus.mobie+"</td>"
                    html += "<td id='cphone'>"+cus.phone+"</td>"
                    html += "<td id='email'>"+cus.email+"</td>"
                    html += "<td >"+cus.education+"</td>"
                    html += "<td>"+cus.school+"</td>"
                    html += "<td>"+cus.address+"</td>"
                    html += "<td>"+cus.census_register+"</td>"
                    html += "<td>"+cus.professional+"</td>"
                    html += "<td>"+cus.company+"</td>"
                    html += "<td>"+cus.company_address+"</td>"
                    html += "<td>"+cus.marital_status+"</td>"
                    html += "<td>"+cus.height+"</td>"
                    html += "<td>"+cus.weight+"</td>"
                    html += "<td>"+cus.hobby+"</td>"
                    html += "<td>"+cus.income+"</td>"
                    html += "<td ><a href="+"'/customer/updCustomer?cid="+cus.cid+"'>修改</a><a href='#' id='delCustomer'>删除</a><a href='/customer/sendMsg?name="+cus.name+"&mobie="+cus.mobie+"&email="+cus.email+"'>通知</a></td>"
                    html += "</tr>"


                })
                $('#showCustomer').html(html)
            }
        })
    }



//渲染完成
$(function () {
    //初始化筛选条件起始日期
    $.ajax({
        type:'GET',
        url:'/customer/initialDate',
        dataType:'json',
        success:function (data) {
            $('#startBirthday').val(data.startBirthday)
            $('#stopBirthday').val(data.stopBirthday)
            $('#startCtime').val(data.startCtime)
            $('#stopCtime').val(data.stopCtime)
        }
    })
    //点击查询按钮事件
    $('#btnQuery').click(function () {
        query();
        $('#sendAll').css('display','inline-block');
        $('#delAll').css('display','inline-block');
    }
    )



	//显示内容1.全选和取消全选
	var isTrue = true;
	//更改状态标识
	$('#checkall').click(function (){

		isTrue = !isTrue;
		if (isTrue){
			$("[name=check]").removeAttr("checked")
		}else{
			$("[name=check]").prop("checked","true");
			}
	});
	/*2.反选
	onchange事件
	输入框监听,来判断两次输入是否一致
	按钮监听,选中与取消状态改变
	*/
    $(document).on("change","[name='check']",function() {
            //not('')获取元素,给出否定条件
            //input:check 匹配别选中的输入框
            //size()获取数组长度,元素个数
            var isAll = $("[name=check]").not("input:checked").size() <= 0;
            if (isAll) {
                //修改全选按钮
                $('#checkall').prop("checked", "true");
                isTrue = false;
            } else {
                $("#checkall").removeAttr("checked");
                isTrue = true;
            }
        });

    //下拉框反选
    var isTrue1 = false;
    $('#sex').click(function (){
		isTrue1 = !isTrue1;
		if (isTrue1==true){
			$("[name=sex]").removeAttr("checked")
		}else{
			$("[name=sex]").prop("checked","true");
			}
	});
    $(document).on("change","[name='sex']",function() {
            //not('')获取元素,给出否定条件
            //input:check 匹配别选中的输入框
            //size()获取数组长度,元素个数
            var isAll = $("[name=sex]").not("input:checked").size() <= 0;
            if (isAll) {
                //修改全选按钮
                $('#sex').prop("checked", "true");
                isTrue1 = false;
            } else {
                $("#sex").removeAttr("checked");
                isTrue1 = true;
            }

        });
    //order下拉框复选反选
    var isTrue2 = false;
    $('#order').click(function (){
		isTrue2 = !isTrue2;
		if (isTrue2==true){
			$("[name=order]").removeAttr("checked")
		}else{
			$("[name=order]").prop("checked","true");
			}
	});
    $(document).on("change","[name='order']",function() {
            //not('')获取元素,给出否定条件
            //input:check 匹配别选中的输入框
            //size()获取数组长度,元素个数
            var isAll = $("[name=order]").not("input:checked").size() <= 0;
            if (isAll) {
                //修改全选按钮
                $('#order').prop("checked", "true");
         $('#order').prop("checked", "true");
                isTrue2 = false;
            } else {
                $("#order").removeAttr("checked");
                isTrue2 = true;
            }

        });

	//3.单个客户删除
	$(document).on("click","#delCustomer",function (){
		cid = $(this).parent().siblings('#cid').html()
		var dic = {
			"cid":cid
		}

		$.ajax({
            type: 'POST',
            data: dic,
            traditional: true,
            url: "/customer/delCustomer",
            success: function () {
                alert('删除成功')
					query()
            }
        })
	});
	//4.批量删除客户
    $('#delAll').click(function () {
        console.log('asdf')
        idList = getIdByCheck()
        console.log(idList)
        if(idList.length>0) {
            var dic = {
                "idList": idList
            }
            $.ajax({
                type: 'POST',
                data: dic,
                traditional: true,
                dataType: 'json',
                url: "/customer/delsCustomer",
                success: function () {
                    alert('删除成功')
                    query()
                }
            })
        }else{alert('请先选择删除对象')}

    })
    //5.批量发通知
    $('#sendAll').click(function () {
        console.log('asdf')
        idList = getIdByCheck()
        console.log('的点点滴滴'+idList.length)
        if(idList.length>0) {
            var dic = {
                "idList": idList
            }
            console.log('fazhong')
            $.ajax({
                type: 'POST',
                data: dic,
                traditional: true,
                dataType: 'json',
                url: "/customer/sendMsg",
                success: function () {
                    alert('发送成功')
                    query()
                }
            })
        }else{alert('请先选择通知对象')}

    })


});
