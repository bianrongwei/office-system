from  .views import *
from django.conf.urls import url

urlpatterns = [
    # url(r'^',echo),
    # url(r'^echo_once', echo_once),
    url(r'^echo', echo),
    url(r'^show', show_views),
    url(r'^ip_views', ip_views),
    url(r'^ip1_views', ip1_views),
    url(r'^ip2_views', ip2_views),
    url(r'^chats', chats),
]
