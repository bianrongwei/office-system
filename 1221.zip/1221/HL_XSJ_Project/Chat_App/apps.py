from django.apps import AppConfig


class ChatAppConfig(AppConfig):
    name = 'Chat_App'
