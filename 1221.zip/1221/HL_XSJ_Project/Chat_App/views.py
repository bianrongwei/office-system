from django.http import HttpResponse
from django.shortcuts import render
from dwebsocket.decorators import accept_websocket, require_websocket
import json
from django.http import JsonResponse


def index(request):
    return  HttpResponse('ASDFASDF')

web1 = {}
ips1=[]
@accept_websocket
def chats(request):
    global web1,ips1
    if not request.is_websocket():
        try:  # 如果是普通的http方法
            message = request.GET['message']
            return HttpResponse(message)
        except:
            return render(request, 'chat1_server.html')
    else:
        ip = request.META['REMOTE_ADDR']
        if ip not in ips1:
            ips1.append(ip)
        web1[ip] = request.websocket
        for message in request.websocket:
            # name = request.session['uname']
            mes = '123:'+ message.decode()
            message = 'a:' + message.decode()
            request.websocket.send(message.encode())
            for i in web1:
                if i != ip:
                    web1[i].send(mes.encode())


def show_views(request):
    return render(request, 'chat_server.html')


ips = []
web = {}
jl = []
ip2 = ''
history = {}

@accept_websocket
def echo(request):
    global ips, web, jl, ip2
    # 判断是不是websocket连接
    if not request.is_websocket():
        try:  # 如果是普通的http方法
            message = request.GET['message']
            print('1',message)
            return HttpResponse(message)
        except:
            return render(request, 'chat_server.html')
    else:

        # 获取客户端ip
        ip = request.META['REMOTE_ADDR']
        if ip not in ips:
            ips.append(ip)

        # 绑定websocket通道
        web[ip] = request.websocket
        history[ip] = []
        if ip!= '127.0.0.1':
            data = '葫芦娃:请问有什么可以帮助到您?'
            request.websocket.send(data.encode())
            history[ip].append(data)
        if ip == '127.0.0.1':
            for i in ips:
                me = 'c:'+ i
                request.websocket.send(me.encode())
            if jl:
                for mes in jl:
                    request.websocket.send(mes.encode())
                    del jl[0]

        for message in request.websocket:
            name = request.session.get('uname','')
            mes = name +':'+ message.decode()
            message = 'a:' + message.decode()
            # 发送消息到客户端
            request.websocket.send(message.encode())
            # jl.append(mes)
            if ip == '127.0.0.1':
                pass
            else:
                jl.append(mes)
                print(jl)

            if ip == '127.0.0.1':
                for i in web:
                    if i == ip2:
                        web[i].send(mes.encode())
                        # del jl[0]
            else:
                for i in web:
                    if i == ip:
                        continue
                    elif i == '127.0.0.1':
                        for mes in jl:
                            web[i].send(mes.encode())
                            del jl[0]


def ip1_views(request):
    if request.method == 'GET':
        global ips
        ip = request.META['REMOTE_ADDR']
        ips.remove(ip)
        return HttpResponse('下线')


def ip_views(request):
    if request.method == 'GET':
        uname = '你好'
        # ips = json.dumps(ips)
        return JsonResponse({"ips": ips})


def ip2_views(request):
    global ip2
    ip = request.META['REMOTE_ADDR']
    print(ip)
    if ip == '127.0.0.1':
        ip2 = request.GET.get('data')
        print(ip2)
        return HttpResponse(ip2)



