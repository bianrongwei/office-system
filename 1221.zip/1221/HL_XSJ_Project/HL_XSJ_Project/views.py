from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
# Create your views here.


def index(request):
    print(request.session.get('uname'))
    if 'uname' in request.session:
        if request.session['uname']=='admin':
            print('在index中判断已登录')
            print(request.session)
            return render(request,"mainAdmin.html")
        elif request.session['uname']:
            return render(request,"main.html")
    else:
        print(request.session)
        print('在index中判断未登录')
        return render(request,'login.html')