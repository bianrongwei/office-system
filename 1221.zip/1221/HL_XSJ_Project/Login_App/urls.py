'''
登录应用
'''
from django.conf.urls import url
from .views import *

#游标
urlpatterns = [
    url(r'^$',login),
    url(r'^logout/',logout),
]
