from django.shortcuts import render, redirect
# Create your views here.
# from django import request


from User_App.views import *
from hashlib import sha1
from User_App.models import *
def login(request):
    if request.method == 'GET':
        if request.session.get('is_login',None):
            return redirect('/index')
        # 判断cookies中是否有登录信息
        elif'uname' in request.COOKIES and 'upwd' in request.COOKIES:
            # cookies中有登录信息,从cookies中取出数据保存进session,并重定向回首页
            uname = request.COOKIES['uname']
            upwd = request.COOKIES['upwd']
            uid = request.COOKIES['uid']
            db_upwd = select_login1(request,uname)
            if upwd == db_upwd:
                print('cnfdjksfss')
                request.session['is_login'] = True
                request.session['uname'] = uname
                request.session['upwd'] = upwd
                request.session['uid'] = uid
                return redirect('/index')
        else:
            # cookie中没有登录信息
            return render(request,'login.html')
    else:
        if request.POST.get('uname')=='admin' and request.POST.get('upwd')=='admin':
            return render(request,'user_show.html')
        else:
            # 处理Post请求
            # 接收前端传递过来的数据并验证登录是否成功
            uname = request.POST.get('uname')
            upwd = request.POST.get('upwd')
            #密码加密比对
            s1 = sha1()
            s1.update(upwd.encode('utf_8'))
            upwd = s1.hexdigest()
            db_upwd = select_login1(request,uname)
            #返回用户对象
            user_object = select_login(request,uname)
            if upwd == db_upwd:
                uid = User.objects.filter(name=uname).values('id').first()['id']
                request.session['is_login'] = True
                request.session['uname'] = uname
                request.session['upwd'] = upwd
                request.session['uid'] = uid
                request.session['user_object'] = user_object
                if 'isSaved' in request.POST:
                    resp = redirect('/index')
                    resp.set_cookie('uname',uname,60*60*24*365)
                    resp.set_cookie('upwd',upwd,60*60*24*365)
                else:
                    resp = redirect('/index')
                uid = select_uid(request,uname)
                resp.set_cookie('uid',uid,60*60*24*365)
                return resp
            else:
                # 登录失败
                errMsg = '用户名或密码不正确'
                return render(request,'login.html', {'errMsg':errMsg})

def logout(request):
    resp = redirect('/login/')
    if 'uname' in request.session :
        del request.session['is_login']
        del request.session['uname']
        del request.session['upwd']
        del request.session['user_object']
    if 'uname' in request.COOKIES:
        resp.delete_cookie('uname')
        resp.delete_cookie('upwd')
        resp.delete_cookie('uid')
    return resp



