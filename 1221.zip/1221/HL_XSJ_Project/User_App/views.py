import json


from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from .models import *
import datetime
import time
# Create your views here.
from hashlib import sha1




#模拟注册
def insert(request):
    if request.method == 'GET':
        return render(request,'register.html')
    else:
        name = request.POST.get('uname')
        password = request.POST.get('upwd')
        #密码加密
        s1 = sha1()
        s1.update(password.encode('utf-8'))
        password = s1.hexdigest()
        email  = request.POST.get('uemail')

        now_time = datetime.datetime.now()
        now_time = datetime.datetime.strftime(now_time, '%Y-%m-%d %H:%M:%S')
        User.objects.create(name=name, password=password,email=email,create_time = now_time )
        return HttpResponse('register successful')


#个人信息查询
def selfUser(request):
    uid = request.session.get('uid')
    user = User.objects.filter(id=uid).get()
    user = User.to_dic(user)
    from django import template

    register = template.Library()

    # 字典过滤器
    @register.filter()
    def hash(h, key):
        if key in h:
            return h[key]
        else:
            return None

    return render(request, 'selfUser.html', locals())


#重要信息修改
def update(request):
    if request.method == 'GET':
        uid = request.GET.get('uid')
        user = User.objects.filter(id=uid).get()
        user = User.to_dic(user)
        from django import template

        register = template.Library()

        # 字典过滤器
        @register.filter()
        def hash(h, key):
            if key in h:
                return h[key]
            else:
                return None


        return  render(request,'update_user.html',locals())
    else:
        uid = request.POST.get('uid')
        professional = request.POST.get('professional')
        address = request.POST.get('address')
        birth_data =request.POST.get('birth_data')
        mobile = request.POST.get('mobile')
        head_protiait = request.FILES.get('head_protiait')
        # 存入的图片名称
        if head_protiait:
            picture_name = str(time.time())+head_protiait.name
            # 将文件写入制定文件夹
            f = open('./static/head_picture/'+picture_name,'wb')
            for line in head_protiait:
                f.write(line)
            f.close()
            head_protiait = './static/head_picture/' + picture_name
        # 将头像地址以字符串形式传到数据库
            User.objects.filter(id=uid).update(professional=professional, address=address,birth_data=birth_data,head_protiait=head_protiait)
        else:
            User.objects.filter(id=uid).update(professional=professional, address=address,birth_data=birth_data)
        return render(request,'user_show.html')


#查询并返回数据
def select(request):
    if request.method == 'GET':
        l = []
        Users = User.objects.filter(isActive=1).all()

        for user in Users:
            user = User.to_dic(user)
            l.append(user)
        return HttpResponse(json.dumps(l))
#删除数据
def delUser(request):
    uid = request.POST.get('uid')
    user = User.objects.filter(id=uid).first()
    print('查询结果',user)
    user.isActive = 0
    user.save()

    return HttpResponseRedirect('/')



#测试,运行时需要带login传入的参数
def select_login(request,name):
    #如果数据库中不存在,返回none
    try:
        user = User.objects.filter(name=name).get()
    except:
        return HttpResponse()

    #获取当前时间，创建时间戳
    ip = request.META['REMOTE_ADDR']

    now_time = datetime.datetime.now()
    now_time = datetime.datetime.strftime(now_time,'%Y-%m-%d %H:%M:%S')

    # 更新lasttime的值
    User.objects.filter(name=name).update(lasttime = now_time,login_address=ip)
    #返回一个数据对象
    dic={
        'id' : user.id,
        'name' : user.name,
        'sex' : user.password,
        'create_time' : user.create_time,
        'lasttime' : user.lasttime,
        'login_address' : user.login_address,
        'mobile' : user.mobile,
        'email' : user.email,
        'professional' : user.professional,
        'address' : user.address,
        'birth_data' : user.birth_data,
        'head_protiait' : user.head_protiait,
        'isActive' : user.isActive,
        'isAdmin' : user.isAdmin,

    }
    return dic

def select_login1(request,name):
    #如果数据库中不存在,返回none
    try:
        user = User.objects.filter(name=name).get()
    except:
        return HttpResponse()
    ip = request.META['REMOTE_ADDR']
    #获取当前时间，创建时间戳
    now_time = datetime.datetime.now()
    now_time = datetime.datetime.strftime(now_time,'%Y-%m-%d %H:%M:%S')

    # 更新lasttime的值
    User.objects.filter(name=name).update(lasttime=now_time, login_address=ip)
    #返回一个数据对象
    upwd = user.password
    return upwd
#根据用户名获取uid
def select_uid(request,name):
    try:
        user = User.objects.filter(name=name).get()
    except:
        return HttpResponse()

    #获取当前时间，创建时间戳
    now_time = datetime.datetime.now()
    now_time = datetime.datetime.strftime(now_time,'%Y-%m-%d %H:%M:%S')

    # 更新lasttime的值
    User.objects.filter(name=name).update(lasttime = now_time)
    #返回一个数据对象
    uid = user.id
    return uid
#根据用户名查重
def select_uname(request,name):
    try:
        user = User.objects.filter(name=name).get()
    except:
        return 0

    #获取当前时间，创建时间戳
    now_time = datetime.datetime.now()
    now_time = datetime.datetime.strftime(now_time,'%Y-%m-%d %H:%M:%S')

    # 更新lasttime的值
    User.objects.filter(name=name).update(lasttime = now_time)
    #返回一个数据对象
    uname = user.name
    return uname

