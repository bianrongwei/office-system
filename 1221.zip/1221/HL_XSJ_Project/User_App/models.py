from django.db import models
class User(models.Model):
    name = models.CharField(max_length=20)
    password = models.CharField(max_length=40)
    sex = models.CharField(max_length=4,default=True)
    #!!
    create_time = models.CharField(max_length=50,null=True)
    lasttime = models.CharField(max_length=50,null=True)
    ##!!
    login_address = models.CharField(max_length=50,null=True)
    mobile = models.CharField(max_length=11,null=True)
    email = models.CharField(max_length=50,null=True)
    professional = models.CharField(max_length=50,null=True)
    address = models.CharField(max_length=50,null=True)
    ##!!
    birth_data = models.CharField(max_length=50,null=True)
    ##!!
    head_protiait = models.CharField(max_length=100,null=True)
    isActive = models.BooleanField(default=True)
    isAdmin = models.BooleanField(default=False)
    def to_dic(self):
        dic = {
            'id': self.id,
            'sex':self.sex,
            'name': self.name,
            'mobile': self.mobile,
            'email': self.email,
            'login_address': self.login_address,
            'professional': self.professional,
            'address': self.address,
            'birth_data': self.birth_data,
            'isAdmin':self.isAdmin
        }
        return dic
# Create your models here.
