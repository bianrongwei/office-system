'''
用户应用
'''
from django.conf.urls import url
from .views import *

#游标
urlpatterns = [
    # url(r'^',index),
    url(r'^zhuce',insert),
    url(r'^123',select_login),
    url(r'^updUser',update),

    url(r'^select',select),
    url(r'^delUser', delUser),
    url(r'^selfUser', selfUser),

]



