from django.apps import AppConfig


class CustomerAppConfig(AppConfig):
    name = 'Customer_App'
