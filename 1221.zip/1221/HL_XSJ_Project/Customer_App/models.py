from django.db import models
class Customer(models.Model):
    id = models.AutoField(primary_key=True, )
    user_id = models.IntegerField(null=True)
    name = models.CharField(max_length=20, )
    sex = models.CharField(max_length=2, )
    birthday = models.DateField(null=True)
    phone = models.CharField(max_length=30, null=True)
    mobie = models.CharField(max_length=30, )
    email = models.EmailField(max_length=50, null=True)
    education = models.CharField(max_length=10, null=True)
    school = models.CharField(max_length=50, null=True)
    address = models.CharField(max_length=100, null=True)
    census_register = models.CharField(max_length=10, null=True)
    professional = models.CharField(max_length=10, null=True)
    company = models.CharField(max_length=50, null=True)
    company_address = models.CharField(max_length=100, null=True)
    marital_status = models.CharField(max_length=2, null=True)
    height = models.FloatField(null=True)
    weight = models.FloatField(null=True)
    hobby = models.CharField(max_length=100, null=True)
    income = models.DecimalField(max_digits=7, decimal_places=2, null=True)
    ctime = models.DateTimeField(auto_now_add=True)
    isActive = models.BooleanField(default=True)
    def to_dic(self):
        dic = {}
        dic['cid'] = self.id
        dic['user_id'] = self.user_id
        dic['name'] = self.name
        dic['sex'] = self.sex
        dic['birthday'] = self.birthday.strftime('%Y-%m-%d')
        dic['phone'] = self.phone
        dic['mobie'] = self.mobie
        dic['email'] = self.email
        dic['education'] = self.education
        dic['school'] = self.school
        dic['address'] = self.address
        dic['census_register'] = self.census_register
        dic['professional'] = self.professional
        dic['company'] = self.company
        dic['company_address'] = self.company_address
        dic['marital_status'] = self.marital_status
        dic['height'] = self.height
        dic['weight'] = self.weight
        dic['hobby'] = self.hobby
        dic['income'] = float(self.income)
        dic['ctime'] = self.ctime.strftime('%Y-%m-%d')
        dic['isActive'] = self.isActive
        return dic




# Create your models here.
