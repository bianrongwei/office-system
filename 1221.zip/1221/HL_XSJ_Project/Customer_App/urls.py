'''
客户应用
'''
from django.conf.urls import url
from .views import *

#游标
urlpatterns = [
    # url(r'',main_views),
    url(r'index',main_views),
    url(r'addOne',addOne_views),
    url(r'query-customers',query_customers),
    url(r'sourCustomer',sourseCustomer),
    url(r'read-excel',upload_views),
    url(r'download',download_views),
    url('test',test_view),
    url(r'^delCustomer',delCustomer),
    url(r'^delsCustomer',delCustomers),
    url(r'^updCustomer', updCustomer),
    url(r'^initialDate',initialDate_views),
    url(r'^sendMsg',sendMsg_views),
    url(r'^sendsMsg', sendMsgs_views),

]
