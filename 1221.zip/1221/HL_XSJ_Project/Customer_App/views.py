import json

from django.core import serializers
from django.db.models.query_utils import Q
from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse, request
from .models import *
# Create your views here.
import xlrd
import xlwt
import datetime
import time


def test_view(request):
    return render(request,'aa.html')

def index(request):
    return HttpResponse('欢迎进入客户应用')
def main_views(request):
    return render(request,'customer.html')
#添加客户信息
def addOne_views(request):
    if request.method == 'GET':
        if 'uid' in request.session:
            return render(request,'customerAddOne.html')
        else:
            return HttpResponseRedirect('/index')
    else:
        user_id = request.session['uid']
        # 获取当前用户id
        user_id = user_id
        name = request.POST.get('name')
        sex = request.POST.get('sex','')
        birthday = request.POST.get('birthday','')
        print('birthday',birthday)
        mobile = request.POST.get('mobile','00')
        phone = request.POST.get('phone','00')
        email = request.POST.get('email','')
        education = request.POST.get('education','')
        school = request.POST.get('school','')
        address = request.POST.get('address','')
        income = request.POST.get('income','12')
        stature = request.POST.get('stature','170')
        weight = request.POST.get('weight','170')
        census_register= request.POST.get('census_register','')
        professional= request.POST.get('professional', '')
        company= request.POST.get('company', '')
        company_address= request.POST.get('company_address', '')
        marital_status= request.POST.get('marital_status', '')
        height= request.POST.get('height', '')




        cus = Customer()
        cus.user_id = user_id
        cus.name = name

        cus.sex = sex
        cus.birthday = birthday
        cus.mobie = int(mobile)
        cus.phone = int(phone)
        cus.email = email
        cus.education = education
        cus.school = school
        cus.address = address
        cus.census_register = census_register
        cus.professional = professional
        cus.company = company
        cus.company_address = company_address
        cus.marital_status = marital_status
        if income:
            cus.income = float(income)
        if weight:
            cus.wight = float(weight)
        if height:
            cus.height = float(stature)
        cus.save()
        return redirect('/customer/query-customers')

#初始化主页客户信息
#获取出生年月及注册时间范围
def initialDate_views(request):
    #获取已存客户信息
    uid = request.session.get('uid')
    birthday = Customer.objects.values_list('birthday').filter(isActive=1,user_id=uid).all()
    ctime = Customer.objects.values_list('ctime').filter(isActive=1,user_id=uid).all()
    birthdaylist = []
    ctimelist = []
    # 如果可以查到生日
    if birthday:
        for b in birthday:
            birthdaylist.append(b[0].strftime('%Y-%m-%d'))
    # 查不到按照当前时间格式化
    else:
        birthdaylist = [time.strftime('%Y-%m-%d',time.localtime(time.time()))]
    # 判断是否可以查到注册日期
    if ctime:
        for c in ctime:
            ctimelist.append(c[0].strftime('%Y-%m-%d'))
    else:
        ctimelist = [time.strftime('%Y-%m-%d',time.localtime(time.time()))]
    dic = {
        'startBirthday':min(birthdaylist),
        'stopBirthday':max(birthdaylist),
        'startCtime':min(ctimelist),
        'stopCtime':max(ctimelist)
    }
    return HttpResponse(json.dumps(dic))


# 查询
def query_customers(request):
    print ('111')
    if request.method == 'GET':
        fields = {'name':'姓名','sex':'性别','birthday':'出生年月','mobie':'手机','phone':'电话','email':'邮箱','education':'学历','school':'毕业院校','address':'住址','census_register':'户籍','company':'公司','professional':'职业','company_address':'公司地址','marital_status':'婚姻状况','height':'身高','weight':'体重','hobby':'爱好','income':'收入'}

        return render(request,'queryCustomer.html',{'fields':fields})
    else:
        l = []
        sex = request.POST.getlist('sex')
        cname = request.POST.get('cname')

        startCtime = datetime.datetime.strptime(request.POST.get('startCtime'),'%Y-%m-%d')+datetime.timedelta(days=-1)
        stopCtime = datetime.datetime.strptime(request.POST.get('stopCtime'),'%Y-%m-%d')+datetime.timedelta(days=2)
        startBirthday = datetime.datetime.strptime(request.POST.get('startBirthday'),'%Y-%m-%d')+datetime.timedelta(days=0)
        stopBirthday = datetime.datetime.strptime(request.POST.get('stopBirthday'),'%Y-%m-%d')+datetime.timedelta(days=0)

        print('aaaa',sex,type(sex))
        user_id = request.session['uid']
        if cname:
            try:
                cname = int(cname)
                customers = Customer.objects.filter(Q(user_id=user_id)&Q(isActive=1)&Q(sex__in=sex)&Q(ctime__gte=startCtime)&Q(ctime__lte=stopCtime)&Q(birthday__gte=startBirthday)&Q(birthday__lte=stopBirthday)&Q(mobie=cname))
            except:
                customers = Customer.objects.filter(Q(user_id=user_id) & Q(isActive=1) & Q(sex__in=sex) & Q(ctime__gte=startCtime) & Q(ctime__lte=stopCtime) & Q(birthday__gte=startBirthday) & Q(birthday__lte=stopBirthday) & Q(name__icontains=cname))
        else:
            customers = Customer.objects.filter(Q(user_id=user_id)&Q(isActive=1)&Q(sex__in=sex)&Q(ctime__gte=startCtime)&Q(ctime__lte=stopCtime)&Q(birthday__gte=startBirthday)&Q(birthday__lte=stopBirthday)).all()

        print(customers)
        print('======')
        for cus in customers:
            cus = Customer.to_dic(cus)
            l.append(cus)
        return HttpResponse(json.dumps(l))

#资源搜索
def sourseCustomer(request):
    print ('这里是sourse')
    if request.method == 'GET':
        fields = {'name':'姓名','sex':'性别','birthday':'出生年月','mobie':'手机','phone':'电话','email':'邮箱','education':'学历','school':'毕业院校','address':'住址','census_register':'户籍','company':'公司','professional':'职业','company_address':'公司地址','marital_status':'婚姻状况','height':'身高','weight':'体重','hobby':'爱好','income':'收入'}

        return render(request,'sourCustomer.html',{'fields':fields})
    else:
        l = []
        sex = request.POST.getlist('sex','')
        inputval = request.POST.get('cname','')
        address = request.POST.get('address','')
        census_register = request.POST.get('census_register')
        startCtime = datetime.datetime.strptime(request.POST.get('startCtime'),'%Y-%m-%d')+datetime.timedelta(days=-1)
        stopCtime = datetime.datetime.strptime(request.POST.get('stopCtime'),'%Y-%m-%d')+datetime.timedelta(days=2)
        startBirthday = datetime.datetime.strptime(request.POST.get('startBirthday'),'%Y-%m-%d')+datetime.timedelta(days=0)
        stopBirthday = datetime.datetime.strptime(request.POST.get('stopBirthday'),'%Y-%m-%d')+datetime.timedelta(days=0)

        print('sourse',sex,type(sex))
        user_id1 = str(request.session['uid'])
        print ('pppp',type(user_id1))
        if inputval:
            try:
                cname = int(inputval)
                customers = Customer.objects.filter(Q(isActive=1)&Q(sex__in=sex)&Q(ctime__gte=startCtime)&Q(ctime__lte=stopCtime)&Q(birthday__gte=startBirthday)&Q(birthday__lte=stopBirthday)&Q(mobie=inputval)).all().limit(10)
            except:
                customers = Customer.objects.filter(Q(isActive=1) & Q(sex__in=sex) & Q(ctime__gte=startCtime) & Q(ctime__lte=stopCtime) & Q(birthday__gte=startBirthday) & Q(birthday__lte=stopBirthday) & Q(name__icontains=inputval)).all().limit(10)
        else:
            customers = Customer.objects.filter(Q(isActive=1)&Q(sex__in=sex)&Q(ctime__gte=startCtime)&Q(ctime__lte=stopCtime)&Q(birthday__gte=startBirthday)&Q(birthday__lte=stopBirthday)).all()[:10]

        print(customers)
        print('++++++++')
        for cus in customers:
            cus = Customer.to_dic(cus)
            l.append(cus)
        return HttpResponse(json.dumps(l))


# 删除客户
def delCustomer(request):
    cid = request.POST.get('cid')

    user_id = request.session['uid']
    customer = Customer.objects.filter(id=cid,user_id=user_id).first()
    print ('====-=-=-=-=',cid, user_id)
    print('查询结果',customer)
    customer.isActive = 0
    customer.save()
    return HttpResponseRedirect('/user/select')
# 批量删除客户
def delCustomers(request):
    idList = request.POST.getlist('idList')
    idlis = []
    for id in idList:
        idlis.append(int(id))
    user_id = request.session['uid']
    Customer.objects.filter(id__in=idlis,user_id=user_id).all().update(isActive=0)
    return HttpResponseRedirect('/user/select')


# 模板解析字典
from django.template.defaulttags import register
@register.filter
def get_item(dictionary, key):
    return dictionary.get(key)
# 修改客户信息
def updCustomer(request):
    if request.method == 'GET':
        cid = request.GET.get('cid')
        print ('cid',cid)
        user_id = request.session['uid']
        customer = Customer.objects.filter(id=cid,user_id=user_id).first()
        print('查询结果',customer)
        customer = Customer.to_dic(customer)
        print(customer)
        from django import template

        register = template.Library()
        # 字典过滤器
        @register.filter()
        def hash(h, key):
            if key in h:
                return h[key]
            else:
                return None

        return render(request,'updateCustomer.html',locals())
    #提交修改后消息
    else:
        # 获取当前用户id
        # user_id = request.session['user_id']
        user_id = 3
        cid = request.POST.get('cid')
        name = request.POST.get('name')
        sex = request.POST.get('sex', '')
        birthday = request.POST.get('birthday', '')
        mobile = request.POST.get('mobile', '')
        phone = request.POST.get('phone', '')
        email = request.POST.get('email', '')
        education = request.POST.get('education', '')
        school = request.POST.get('school', '')
        address = request.POST.get('address', '')
        income = request.POST.get('income', '12')
        stature = request.POST.get('stature', '170')
        weight = request.POST.get('weight', '170')
        census_register = request.POST.get('census_register', '')
        professional = request.POST.get('professional', '')
        company = request.POST.get('company', '')
        company_address = request.POST.get('company_address', '')
        marital_status = request.POST.get('marital_status', '')
        height = request.POST.get('height', '')
        print ('--------------')
        print (cid,type(cid))
        cus = Customer.objects.filter(id=int(cid)).first()
        cus.name = name
        print ('kaishicunzu')
        cus.sex = sex
        cus.birthday = birthday
        cus.mobie = mobile
        cus.phone = phone
        cus.email = email
        cus.education = education
        cus.school = school
        cus.address = address
        cus.census_register = census_register
        cus.professional = professional
        cus.company = company
        cus.company_address = company_address
        cus.marital_status = marital_status
        if income:
            cus.income = float(income)
        if weight:
            cus.wight = float(weight)
        if height:
            cus.height = float(stature)
        cus.save()
        return redirect('/customer/query-customers')

        return HttpResponse('ASDF')

# 文件上传
def upload_views(request):

    if request.method == 'GET':
        return render(request,'uploadCustomer.html')
    else:
        user_id = request.session['uid']
        file = request.FILES['file'].read()
        # 打开文件
        file_path = '/Users/bianrongwei/Desktop/test.xlsx'
        # file_path = '/static/model/test.xlsx'

        data = xlrd.open_workbook(filename=None,file_contents=file)
        #获取第一个sheet 的行数及列数
        sheet1 = data.sheet_by_index(0)
        rows = sheet1.nrows
        cols = sheet1.ncols
        print(rows,cols)
        #读取数据
        for row in range(1,rows):
            print('测试')
            rowValues = sheet1.row_values(row)
            print(rowValues)
            customer = Customer()
            customer.user_id = user_id
            customer.name = rowValues[1]
            customer.sex = rowValues[2]
            date_value = xlrd.xldate_as_tuple(sheet1.cell_value(row,3),data.datemode)
            date_tmp = datetime.date(*date_value[:3]).strftime('%Y-%m-%d')
            customer.birthday = date_tmp
            if rowValues[4]:
                customer.phone = int(rowValues[4])
            if rowValues[4]:

                customer.mobie = int(rowValues[5])
            customer.email = rowValues[6]
            customer.education = rowValues[7]
            customer.school = rowValues[8]
            customer.address = rowValues[9]
            customer.census_register = rowValues[10]
            customer.professional = rowValues[11]
            customer.company = rowValues[12]
            customer.company_address = rowValues[13]
            customer.marital_status = rowValues[14]
            if rowValues[15]:
                customer.height =float(rowValues[15])
            if rowValues[16]:
                customer.weight = float(rowValues[16])
            customer.hobby = rowValues[17]
            customer.income = float(rowValues[18])

            print(customer)
            customer.save()
        return HttpResponseRedirect('/customer/addOne')

#文件导出
import os,django,sys
BASE_DIR =os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)

#发送消息


# 批量通知客户
def sendMsgs_views(request):
    print('dddd')
    idList = request.POST.getlist('idList')
    idlis = []
    for id in idList:
        idlis.append(int(id))
    custome = Customer.objects.filter(id__in=idlis).values_list('mobie','email')
    print(custome)
    return HttpResponse('ddd')
def download_views(request):
    download_url = '/Users/bianrongwei/Desktop/'
    dbname = ''
    style0 = xlwt.easyxf('font:name Time New Roman,color-index red,bold on')
    style1 = xlwt.easyxf(num_format_str='D-MMM-YY')
    #获取字段名
    field_name_list = []
    field_verbose_name_list = []

    wb = xlwt.Workbook()
    ws = wb.add_sheet('客户信息表',cell_overwrite_ok=True)
    for i in range(len(field_verbose_name_list)):
        ws.write(0,i,field_verbose_name_list[i],style0)
    
    mylist = []
    log_obj = Customer.object.all()
    num = 0
    for i in log_obj.values():
        mylist.append([])
        for j in range(len(field_name_list)):
            mylist[num].append(i[field_name_list[j]])
        num += 1
    for i in range(0,log_obj.count()):
        for j in range(len(field_verbose_name_list)):
            ws.write(i+1,mylist[i][j])
    timestr = datetime.now().strftime('%Y%m%d%H%M%S')
    wb.save(download_url+'new-'+timestr+'.xls')

    from django.http import StreamingHttpResponse
    def file_iterator(file_name,chunk_size = 512):
        with open(download_url+'new-'+timestr+'.xls') as f:
            while True:
                c = f.read(512)
                if c:
                    yield c
                else:
                    break
    the_file_name = 'new-'+timestr+'.xls'
    response = StreamingHttpResponse(file_iterator(download_url+'new-'+timestr+'.xls'))
    response['Content-Type'] = 'application/octet-stream'
    response['Content-Disposition'] = 'attachment;filename="{0}"'.format(the_file_name)

    return response

#短信通知客户
from urllib import request
from urllib import parse
from urllib.request import urlopen
import random


def sendMsg_views(request):
    #用户名 查看用户名请登录用户中心->验证码、通知短信->帐户及签名设置->APIID
    account  = "C11103528"
    #密码 查看密码请登录用户中心->验证码、通知短信->帐户及签名设置->APIKEY
    password = "e06e242878bddac227d1c2892bf9bd22"
    if request.method == 'GET':
        name = request.GET.get('name')
        mobie = request.GET.get('mobie')
        print(mobie,type(mobie))
        email = request.GET.get('email')
        Random6 = str(random.randint(0,9)) + str(random.randint(0,9))+str(random.randint(0,9))+str(random.randint(0,9))+str(random.randint(0,9))+str(random.randint(0,9))
        # text = ("葫芦娃欢迎预祝您圣诞节快乐!")
        text = ("您的验证码是：%i。请不要把验证码泄露给其他人。" % int(Random6))
        data = {'account': account, 'password' : password, 'content': text, 'mobile':mobie,'format':'json' }
        req = urlopen(
        url= 'http://106.ihuyi.com/webservice/sms.php?method=Submit',
        data= parse.urlencode(data).encode('utf-8')
        )
        content =req.read().decode()
        print(content)
    else:
        idList = request.POST.getlist('idList')
        idlis = []
        for id in idList:
            idlis.append(int(id))
        mobies = Customer.objects.filter(id__in=idlis).values_list('mobie')
        for mobie in mobies:
            mobie = mobie[0]
            print(mobie)
            Random6 = str(random.randint(0, 9)) + str(random.randint(0, 9)) + str(random.randint(0, 9)) + str(
                random.randint(0, 9)) + str(random.randint(0, 9)) + str(random.randint(0, 9))
            # text = ("葫芦娃欢迎预祝您圣诞节快乐!")
            text = ("您的验证码是：%i。请不要把验证码泄露给其他人。" % int(Random6))
            data = {'account': account, 'password': password, 'content': text, 'mobile': mobie, 'format': 'json'}
            req = urlopen(
                url='http://106.ihuyi.com/webservice/sms.php?method=Submit',
                data=parse.urlencode(data).encode('utf-8')
            )
    return HttpResponse('短信发送成功')










